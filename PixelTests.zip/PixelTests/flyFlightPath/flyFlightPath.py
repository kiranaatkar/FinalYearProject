import csv; import cv2
import numpy as np
from scipy.interpolate import UnivariateSpline

#Variables to be used to configure the video
width = 1280; height = 720; FPS = 60

#Circle parameters
radius = 15


# Write video file
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
video = cv2.VideoWriter('flyFlightPath.mp4', fourcc, float(FPS), (width, height))

path = r'C:\Users\Kit\Desktop\PixelTests\flyFlightPath\Dataset'
groundtruth = open(str(path)+'\GroundTruth.txt',"w+")


# get flight coors 
x_coors = []; y_coors = []

with open('flyFlightCoors.csv') as f:
    reader = csv.reader(f)
    for line in reader:
        coors = line[0].split(' ')
        x_coors.append(round(float(coors[0])))
        y_coors.append(round(float(coors[1])))
        

old_x = np.arange(0,len(x_coors))
new_length = 500
new_indices = np.linspace(0,len(x_coors)-1,new_length)
spl = UnivariateSpline(old_x,x_coors,k=3,s=0)
x_coors = spl(new_indices)

old_y = np.arange(0,len(y_coors))
new_length = 500
new_indices = np.linspace(0,len(y_coors)-1,new_length)
spl = UnivariateSpline(old_y,y_coors,k=3,s=0)
y_coors = spl(new_indices)



count = 0


# Create vid
for x_coor, y_coor in zip(x_coors, y_coors):
    count += 1
    #First, create white frame
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    frame.fill(255)
    
    #Add circle at new position
    centre = (round(x_coor), round(y_coor))
    cv2.circle(frame, centre, radius, (0, 0, 0), -1)
    
    #Add bounding box
    #cv2.rectangle(frame, (round(x_coor - radius), round(y_coor + radius)), (round(x_coor + radius), round(y_coor - radius)), \
    #              (0, 0, 255), 2)

    video.write(frame)
    cv2.imwrite(str(path) + '\IMG'+str(count)+'.jpg', frame)
    
    
    #groundtruth file
    groundtruth.write(str(x_coor - radius) + '\t' + str(y_coor + radius) + \
                      '\t' + str(2*radius) + '\t' + str(2*radius) + '\n')

video.release()
groundtruth.close()


still = np.zeros((height, width, 3), dtype = np.uint8)
still.fill(255)
for x_coor, y_coor, i in zip(x_coors, y_coors, range(len(x_coors))):
    if i < len(x_coors) - 1:     
        cv2.line(still, (round(x_coor), round(y_coor)), (round(x_coors[i+1]), round(y_coors[i+1])) , (0, 0, 0), 2)
    
cv2.circle(still, (round(x_coors[3]), round(y_coors[3])), radius, (0, 0, 0), -1)
    
cv2.imwrite(r'C:\Users\Kit\Desktop\PixelTests\flyFlightPath\flyflightpath.jpg', still)


















