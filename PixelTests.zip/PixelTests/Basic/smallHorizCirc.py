import cv2
import numpy as np

#Variables to be used to configure the video
width = 1280; height = 720; FPS = 60


#Circle parameters
radius = 25


# Write video file
fourcc = cv2.VideoWriter_fourcc(*'MP4V')
video = cv2.VideoWriter('smallHorizCirc.mp4', fourcc, float(FPS), (width, height))

path = r'C:\Users\Kit\Desktop\PixelTests\Basic\Dataset'
groundtruth = open(str(path)+'\GroundTruth.txt',"w+")


# Creating video frame by frame with numpy array

y_coor = int(height/2) #Puts circle in the centre of the screen
x_coors = [*range(radius, width-radius, 5)]
x_coors = x_coors + x_coors[::-1]

count = 0

for x_coor in x_coors:
    
    count += 1
    #First, create white frame
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    frame.fill(255)
    
    #Add circle at new position
    cv2.circle(frame, (x_coor, y_coor), radius, (0, 0, 0), -1)
    
    #Add bounding box
    #cv2.rectangle(frame, (x_coor - radius, y_coor + radius), (x_coor + radius, y_coor - radius), \
    #              (0, 0, 255), 2)

    video.write(frame)
    if count < 100:
        if count < 10:
            cv2.imwrite(str(path) + '\IMG000'+str(count)+'.jpg', frame)
        else:
            cv2.imwrite(str(path) + '\IMG00'+str(count)+'.jpg', frame)
    else:
        cv2.imwrite(str(path) + '\IMG0'+str(count)+'.jpg', frame)
    
    
    #groundtruth file
    groundtruth.write(str(x_coor - radius) + '\t' + str(y_coor + radius) + \
                      '\t' + str(2*radius) + '\t' + str(2*radius) + '\n')

video.release()
groundtruth.close()

#Create still frame
still = np.zeros((height, width, 3), dtype = np.uint8)
still.fill(255)
for x_coor, i in zip(x_coors, range(len(x_coors))):
    if i < len(x_coors) - 1:    
        cv2.line(still, (x_coor, y_coor), (x_coors[i+1], y_coor) , (0, 0, 0), 2)
    
cv2.circle(still, (x_coors[12], y_coor), radius, (0, 0, 0), -1)
    
cv2.imwrite(r'C:\Users\Kit\Desktop\PixelTests\Basic\straight.jpg', still)
