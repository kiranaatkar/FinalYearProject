function Out2=NewFilter2(u,tau)
    %Ts = 0.05;
    Ts = 0.001;
    Out2 = (exp(-(Ts./tau))).*u;
end