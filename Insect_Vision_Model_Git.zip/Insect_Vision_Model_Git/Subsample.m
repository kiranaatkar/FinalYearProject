function SubSampledGreen=Subsample(Green, pixel2PR)

    SubSampledGreen=Green(1:pixel2PR:end,1:pixel2PR:end);
end