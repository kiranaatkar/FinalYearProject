%  Bagheri Z.B., Wiederman S.D., Cazzolato B.S., Grainger S., O'Carroll
%  D.C. (2017) "Performance of an Insect-Inspired Target Tracker in Natural Conditions"
%  
%
%  This MATLAB code implements an insect-inspired target tracking (IIT) model. 

%  It is free for research use. If you find it useful, please acknowledge the paper
%  above with a reference.

%  This function takes care of setting up parameters, loading video
%  information and computing precisions. 

%%%%%%%%%%% path to the videos %%%%%%%%%%%%
L=; %video number
video_path=['C:\Dataset\' num2str(L)];
cd(video_path)
img_files = dir('*.png');
if isempty(img_files)
    img_files = dir('*.jpg');
end
if isempty(img_files)
    img_files = dir('*.tif');
end
if isempty(img_files)
    assert(~isempty(img_files), 'No image files to load.')
end
nFrames=size(img_files,1);
dataGreenChannel=[];

if L == 13 || L==14 || L==15 % As these videos are gray scale, there's only one channel
    for IN=1:nFrames
        Frame=imread(img_files(IN).name);
        dataGreenChannel(:,:,IN)=Frame(:,:,1);
    end
    
else
    for IN=1:nFrames
        Frame=imread(img_files(IN).name);
        dataGreenChannel(:,:,IN)=Frame(:,:,2);
    end
    
    
end


% Uncomment to convert every frame to gray scale
% for IN=1:nFrames
%     Frame=imread(img_files(IN).name);
%     %Frame = rgb2gray(Frame);
%     dataGreenChannel(:,:,IN)=Frame(:,:,1);
% end
groundtruth = dlmread('GroundTruth.txt');

%%%%%%%%%%% Path to the code %%%%%%%%%%%%%%%
codeDirectory=['C:\Insect_Vision_Model'];
cd(codeDirectory)

%%%%%%%%%%% Set the Parameters %%%%%%%%%%%%

%Center of the target in the first frame
X_C=(groundtruth(1,1)+groundtruth(1,3)/2);   
Y_C=groundtruth(1,2)+groundtruth(1,4)/2;  

%Image size
image_size_m = size(dataGreenChannel,1) ;                         %number of rows
image_size_n = size(dataGreenChannel,2);                         %number of columns
Facilitation_Mode='on';


%Facilitation parameters
Facilitation_sigma=5/2.35482;
Ts = 0.05; %Sampling time

    
FacilitationGain = 25; %root of facilitation kernel gain
RC_wb = 5; 
parameter.RC_fac_wb = 1;
Threshold = 0.1;
TargetLocationRow=zeros(nFrames,1);
TargetLocationCol=zeros(nFrames,1);
framePTime=zeros(nFrames,1);
blurPTime=zeros(nFrames,1);
Delay=200; % allowing the facilitation to build up in the target region for 200 ms prior to the start of the experiment. 


% Set up for nested loop

HFV_vals = 30:10:80;
nHFV = length(HFV_vals);

wb_vals = [0.01 0.015 0.0175 0.0275 0.04 0.05 0.1 0.2 0.5, 1, 1.25, 1.5, 1.75, 2];
nwb = length(wb_vals);

delay_vals = 1:1:21;
ndelay = length(delay_vals);

directory0 = [video_path '\success'];
mkdir(directory0)
cd(directory0)
success = cell(2, nHFV*nwb*ndelay);
count = 0;

for j = 1 : nHFV
    degrees_in_image =HFV_vals(j); % Facilitation time constant
    pixels_per_degree = image_size_n/degrees_in_image;                          %pixels_per_degree = #horiz. pixels in output / horizontal degrees (97.84)
    pixel2PR = ceil(pixels_per_degree);                                         %ratio of pixels to photoreceptors in the bio-mimetic model (1 deg spatial sampling...                                                                
    sigma_deg = 1.4/2.35; 
    sigma_pixel = sigma_deg*pixels_per_degree;                                  %sigma = (sigma in degrees (0.59))*pixels_per_degree
    kernel_size = 2*(ceil(sigma_pixel));
    ParameterResize=ceil(image_size_m/pixel2PR);
    K1=1:pixel2PR:image_size_m;
    K2=1:pixel2PR:image_size_n;
    YDim=length(K1);
    XDim=length(K2);

    Facilitation_Matrix=ones(YDim, XDim);

    %Initial target location in the subsampled image
    initialCol=ceil(X_C/pixel2PR);
    initialRow=ceil(Y_C/pixel2PR);
    
    for k = 1 : nwb
        wb = wb_vals(k);
        
        for m = 1 : ndelay
            count = count + 1;
            dly = delay_vals(m);
            inBoundingBox = zeros(nFrames, 1);
            for i=1:nFrames+Delay
                if i>=2
                    test=1;
                    start=1;
                else
                    test=0;
                    start=0;
                end 
                if i>Delay
                    Input=dataGreenChannel(:,:,i-Delay);
                    Input=double(Input);
        
                else
                    Input=ones(image_size_m,image_size_n);
                end
   
                tic;
                tStart = tic;
                opticOut=OpticBlur(Input, pixels_per_degree);
                tBlur = toc(tStart);
                SubSampledGreen=Subsample(opticOut, pixel2PR);
                PR_Output=PhotoReceptor(SubSampledGreen, XDim, YDim);
                LMC_Output=LMC(PR_Output, XDim,YDim);
                RTC_Output=RTC(LMC_Output, Ts);
                ESTMD_OUT=ESTMD(RTC_Output, Facilitation_Matrix, Facilitation_Mode, start, Threshold); 
                [Direction_Horizontal,Direction_Vertical]=Direction(ESTMD_OUT,  RC_wb, Ts,XDim, YDim);
                [ col_index, row_index] = Target_Location(ESTMD_OUT, YDim);
                [default, col_index2,row_index2] = Velocity_Vector(test, col_index, row_index,Direction_Horizontal,Direction_Vertical, XDim);
                if i<=Delay
                    default=1;
                end
       
                if i<Delay+1
                    col_index2=initialCol;
                    row_index2=initialRow;
                end
   
                Grid=FacilitationGrid(col_index2,row_index2, ESTMD_OUT, Facilitation_sigma, FacilitationGain);
                Facilitation_Matrix=FacilitationMatrix(Grid, col_index2, default, Ts, wb);
                tFrame=toc;
                if i>Delay
                    TargetLocationRow(i-Delay)=row_index * pixel2PR;
                    TargetLocationCol(i-Delay)=col_index * pixel2PR;
       
                    %Check if in bounding box
                    if i > Delay + dly
                        if (groundtruth(i-Delay-dly, 1) <= TargetLocationCol(i-Delay)) && (TargetLocationCol(i-Delay) <= (groundtruth(i-Delay-dly, 1) + groundtruth(i-Delay-dly, 3)))...
                            && (groundtruth(i-Delay-dly, 2) <= TargetLocationRow(i-Delay)) && (TargetLocationRow(i-Delay) <= (groundtruth(i-Delay-dly, 2) + groundtruth(i-Delay-dly, 4)))
        
                            inBoundingBox(i-Delay) = 1;
       
                        else
                            inBoundingBox(i-Delay) = 0;
   
                        end

                    end
                    
                    %Uncomment to see frame printed out with bounding box
                    %and winning feature
%                   if i>Delay
%                       image = fullfile(video_path, img_files(i-Delay).name); % Added by me
%                       Frame=imread(image);
%                       figure, imshow(Frame)
%                       pos_gt = [groundtruth(i-Delay, 1), groundtruth(i-Delay, 2), groundtruth(i-Delay, 3), groundtruth(i-Delay, 4)];
%                       rectangle('Position', pos_gt, 'EdgeColor', 'r')
%                       hold on
%                       plot(TargetLocationCol(i-Delay), TargetLocationRow(i-Delay), 'c*')
%         
%                   end
                end
                framePTime(i)=tFrame;
                blurPTime(i)=tBlur; 
                
           
            
            end
            success{1, count} = "HFOV:" + degrees_in_image + ", wb:" + wb + " Delay:" + dly;
            success{2, count} = (sum(inBoundingBox(2:end))/nFrames) * 100;
            save('success_closetomax', 'success')
            clear functions
        end
    end
end
directory1=[video_path '\results'];   

mkdir(directory1)
cd(directory1)


save('TargetLocationRow','TargetLocationRow')
save('TargetLocationCol','TargetLocationCol')
save('framePTime','framePTime')
save('blurPTime', 'blurPTime')
clear functions
   
