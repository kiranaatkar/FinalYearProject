function Out1=NewFilter1(u, tau)
    %Ts=0.05;
    Ts = 0.001;
    Out1 = (1-exp(-(Ts./tau))).*u;
end